<?php $__env->startSection('title', 'Вход'); ?>

<?php $__env->startSection('content'); ?>
<div style="max-width:420px;margin:60px auto">
    <div class="card">
        <h1 style="font-size:22px;margin-bottom:16px;color:var(--primary)">🏥 Вход в МедПортал</h1>

        <form method="POST" action="<?php echo e(route('login.store')); ?>">
            <?php echo csrf_field(); ?>
            <div>
                <label for="email">E-mail (корпоративный)</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:16px">
                <input type="checkbox" id="remember" name="remember" value="1" style="width:auto;margin:0">
                <label for="remember" style="margin:0">Запомнить меня</label>
            </div>
            <button type="submit" class="btn" style="width:100%">Войти</button>
        </form>

        <p style="color:var(--muted);font-size:12px;margin-top:16px">
            Тестовые учётные записи: admin@portal.local / chief@portal.local / hr@portal.local — пароль <b>password</b>
        </p>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspace/portal-php/resources/views/auth/login.blade.php ENDPATH**/ ?>