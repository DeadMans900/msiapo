<?php $__env->startSection('title', 'Главная'); ?>

<?php $__env->startSection('content'); ?>
<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px">
    <h1>Добро пожаловать, <?php echo e(auth()->user()->name); ?> 👋</h1>
    <span class="badge"><?php echo e(now()->format('d.m.Y')); ?> · <?php echo e(['вс','пн','вт','ср','чт','пт','сб'][now()->dayOfWeek]); ?></span>
</div>


<?php
    $widgets = [
        ['icon'=>'📖','title'=>'Справочник','route'=>'phonebook.index','ready'=>true,'count'=>$phonebookCount,'hint'=>'сотрудников'],
        ['icon'=>'📑','title'=>'Приказы','route'=>null,'ready'=>false,'count'=>$ordersUnread,'hint'=>'непрочитанных'],
        ['icon'=>'📘','title'=>'СОПы','route'=>null,'ready'=>false,'count'=>$sopsUnread,'hint'=>'к обязательному прочтению'],
        ['icon'=>'🛠','title'=>'HelpDesk','route'=>null,'ready'=>false,'count'=>$ticketsOpen,'hint'=>'открытых заявок'],
        ['icon'=>'📝','title'=>'Ходатайства','route'=>null,'ready'=>false,'count'=>$requestsNew,'hint'=>'новых'],
        ['icon'=>'📅','title'=>'Календарь','route'=>null,'ready'=>false,'count'=>$eventsUpcoming,'hint'=>'ближайших событий'],
    ];
?>
<div class="grid" style="margin-bottom:24px">
    <?php $__currentLoopData = $widgets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card widget <?php if (! ($w['ready'])): ?> disabled <?php endif; ?>">
            <?php if($w['ready']): ?>
                <a href="<?php echo e(route($w['route'])); ?>" class="widget-link">
                    <span class="widget-icon"><?php echo e($w['icon']); ?></span>
                    <div><strong><?php echo e($w['title']); ?></strong>
                        <div class="widget-count"><?php echo e(number_format($w['count'])); ?> <span><?php echo e($w['hint']); ?></span></div>
                    </div>
                </a>
            <?php else: ?>
                <span class="widget-icon" style="opacity:.4"><?php echo e($w['icon']); ?></span>
                <div><strong><?php echo e($w['title']); ?></strong>
                    <div class="widget-count muted">в разработке</div>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;align-items:start">
    <div>
        
        <div class="card">
            <h3 class="card-title">📰 Новости портала</h3>
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="news-item">
                    <div class="news-date"><?php echo e($n->published_at->format('d.m.Y')); ?></div>
                    <div>
                        <strong><?php echo e($n->title); ?></strong>
                        <p><?php echo e($n->body); ?></p>
                        <?php if($n->author): ?><small class="muted">— <?php echo e($n->author->name); ?></small><?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Новостей пока нет.</p>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <h3 class="card-title">🩺 Дежурства на сегодня</h3>
            <?php if($duties->isEmpty()): ?>
                <p class="muted">График дежурств на сегодня не заполнен (модуль «Календарь и дежурства» — впереди).</p>
            <?php else: ?>
                <table class="data">
                    <tr><th>Служба</th><th>ФИО</th><th>Связь</th></tr>
                    <?php $__currentLoopData = $duties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr><td><?php echo e($d->service); ?></td><td><?php echo e($d->fio); ?></td><td><?php echo e($d->phone); ?></td></tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            <?php endif; ?>
        </div>
    </div>

    <div>
        
        <div class="card">
            <h3 class="card-title">🔗 Внешние системы</h3>
            <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a class="ext-link" href="<?php echo e($l->url); ?>" target="_blank" rel="noopener">↗ <?php echo e($l->name); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">Список ссылок пуст.</p>
            <?php endif; ?>
        </div>

        
        <div class="card">
            <h3 class="card-title">🎂 Дни рождения месяца</h3>
            <?php $__empty_1 = true; $__currentLoopData = $birthdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="bday">
                    <span class="bday-date"><?php echo e($b->birth_date->format('d.m')); ?></span>
                    <span><?php echo e($b->fio_short); ?></span>
                    <?php if($b->department): ?><small class="muted">· <?php echo e($b->department->short_name ?? $b->department->name); ?></small><?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="muted">В этом месяце дней рождения нет.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspace/portal-php/resources/views/home.blade.php ENDPATH**/ ?>