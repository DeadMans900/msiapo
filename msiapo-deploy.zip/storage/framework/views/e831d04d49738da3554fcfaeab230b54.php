<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Корпоративный портал'); ?> — МедПортал</title>
    <?php echo $__env->yieldPushContent('head'); ?>
    <style>
        :root{--primary:#1266a8;--accent:#e8f2fa;--text:#233044;--muted:#7b8794;--border:#dfe6ee;}
        *{box-sizing:border-box;margin:0;padding:0}
        body{font-family:'Segoe UI',Roboto,Arial,sans-serif;color:var(--text);background:#f4f7fa}
        header.topbar{background:var(--primary);color:#fff;display:flex;align-items:center;gap:24px;padding:0 24px;height:56px}
        header.topbar a.brand{color:#fff;font-weight:700;font-size:18px;text-decoration:none}
        header.topbar nav{display:flex;gap:4px;flex:1}
        header.topbar nav a{color:#dceaf6;text-decoration:none;padding:8px 14px;border-radius:6px;font-size:14px}
        header.topbar nav a:hover,header.topbar nav a.active{background:rgba(255,255,255,.15);color:#fff}
        header.topbar .user{font-size:14px}
        main{max-width:1200px;margin:24px auto;padding:0 24px}
        footer{color:var(--muted);text-align:center;padding:24px;font-size:13px}
        .card{background:#fff;border:1px solid var(--border);border-radius:10px;padding:20px;margin-bottom:16px}
        table.data{width:100%;border-collapse:collapse;background:#fff}
        table.data th{background:var(--accent);text-align:left;padding:10px;font-size:13px;color:var(--primary)}
        table.data td{padding:10px;border-bottom:1px solid var(--border);font-size:14px}
        .badge{display:inline-block;padding:2px 10px;border-radius:12px;font-size:12px;background:var(--accent);color:var(--primary)}
        .btn{display:inline-block;background:var(--primary);color:#fff;border:none;padding:10px 18px;border-radius:6px;cursor:pointer;text-decoration:none;font-size:14px}
        .btn:hover{filter:brightness(1.1)}
        input,select,textarea{width:100%;padding:10px;border:1px solid var(--border);border-radius:6px;font:inherit;margin-bottom:12px}
        label{display:block;font-size:13px;color:var(--muted);margin-bottom:4px}
        .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:16px}
        
        .muted{color:var(--muted)}
        .card-title{color:var(--primary);margin-bottom:12px;font-size:16px}
        .widget{padding:0}
        .widget a.widget-link{display:flex;align-items:center;gap:14px;padding:18px;text-decoration:none;color:inherit}
        .widget.disabled{opacity:.5;background:#fafbfc}
        .widget .widget-icon{font-size:26px}
        .widget-count{font-size:22px;font-weight:700;color:var(--primary)}
        .widget-count span{font-size:12px;font-weight:400;color:var(--muted)}
        .news-item{display:flex;gap:14px;padding:10px 0;border-bottom:1px solid var(--border)}
        .news-item:last-child{border-bottom:none}
        .news-date{color:var(--muted);font-size:12px;white-space:nowrap;padding-top:3px}
        .news-item p{font-size:14px;color:var(--text);margin-top:2px}
        .ext-link{display:block;padding:8px 10px;border-radius:6px;color:var(--primary);text-decoration:none;font-size:14px}
        .ext-link:hover{background:var(--accent)}
        .bday{display:flex;gap:8px;align-items:baseline;padding:6px 0;border-bottom:1px dashed var(--border);font-size:14px}
        .bday:last-child{border-bottom:none}
        .bday-date{font-weight:700;color:var(--primary);min-width:44px}
        .alert-danger{background:#fdecea;color:#b3261e;padding:10px;border-radius:6px;margin-bottom:16px;font-size:14px}
    </style>
</head>
<body>
<header class="topbar">
    <a class="brand" href="<?php echo e(route('home')); ?>">🏥 МедПортал</a>
    <nav>
        <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->routeIs('home')?'active':''); ?>">Главная</a>
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('phonebook.index')); ?>" class="<?php echo e(request()->routeIs('phonebook.*')?'active':''); ?>">Справочник</a>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('module.hr')): ?>
                <a href="<?php echo e(route('hr.index')); ?>" class="<?php echo e(request()->routeIs('hr.*')?'active':''); ?>">Кадры</a>
            <?php endif; ?>
        <?php endif; ?>
    </nav>
    <div class="user">
        <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('profile')); ?>" style="color:#fff;text-decoration:none" class="<?php echo e(request()->routeIs('profile')?'active':''); ?>">
                <?php echo e(auth()->user()->name); ?>

            </a>
            <span class="badge" style="background:rgba(255,255,255,.2);color:#fff"><?php echo e(config('portal.roles')[auth()->user()->role] ?? auth()->user()->role); ?></span> ·
            <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <button type="submit" style="background:none;border:none;color:#fff;cursor:pointer;text-decoration:underline;font-size:14px">Выйти</button>
            </form>
        <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" style="color:#fff">Войти</a>
        <?php endif; ?>
    </div>
</header>
<main>
    <?php if(session('status')): ?><div class="alert" style="background:#e6f4ea;color:#1e7e34;padding:10px;border-radius:6px;margin-bottom:16px"><?php echo e(session('status')); ?></div><?php endif; ?>
    <?php if($errors->any()): ?><div class="alert-danger"><?php echo e($errors->first()); ?></div><?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</main>
<footer>МедПортал © <?php echo e(date('Y')); ?> · Laravel <?php echo e(app()->version()); ?> · MySQL</footer>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /workspace/portal-php/resources/views/layouts/app.blade.php ENDPATH**/ ?>