<?php $__env->startSection('title', 'Личный кабинет'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:16px">Личный кабинет</h1>

<div class="grid" style="align-items:start">
    <div class="card">
        <h2 style="font-size:16px;color:var(--primary);margin-bottom:12px">Профиль</h2>
        <table class="data" style="background:transparent">
            <tr><th>ФИО</th><td><?php echo e($user->name); ?></td></tr>
            <tr><th>E-mail</th><td><?php echo e($user->email); ?></td></tr>
            <tr><th>Роль</th><td><span class="badge"><?php echo e($rolesMap[$user->role] ?? $user->role); ?></span></td></tr>
            <?php if($user->employee): ?>
                <tr><th>Подразделение</th><td><?php echo e($user->employee->department?->name ?? '—'); ?></td></tr>
                <tr><th>Должность</th><td><?php echo e($user->employee->position ?? '—'); ?></td></tr>
                <tr><th>Телефон</th><td><?php echo e($user->employee->phone ? 'вн. ' . $user->employee->phone : '—'); ?></td></tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="card">
        <h2 style="font-size:16px;color:var(--primary);margin-bottom:12px">Смена пароля</h2>
        <form method="POST" action="<?php echo e(route('profile.password')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="current_password">Текущий пароль</label>
            <input type="password" id="current_password" name="current_password" required>
            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="password">Новый пароль (мин. 8 символов)</label>
            <input type="password" id="password" name="password" required minlength="8">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="alert-danger"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <label for="password_confirmation">Повторите новый пароль</label>
            <input type="password" id="password_confirmation" name="password_confirmation" required minlength="8">

            <button type="submit" class="btn">Изменить пароль</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspace/portal-php/resources/views/auth/profile.blade.php ENDPATH**/ ?>