<?php $__env->startSection('title', 'Справочник'); ?>

<?php $__env->startSection('content'); ?>
<h1 style="margin-bottom:16px">Справочник сотрудников и подразделений</h1>

<form method="GET" action="<?php echo e(route('phonebook.index')); ?>" style="display:flex;gap:12px;margin-bottom:20px">
    <input type="text" name="q" placeholder="Поиск по ФИО, должности, телефону…" value="<?php echo e(request('q')); ?>" style="flex:2;margin:0">
    <select name="department_id" style="flex:1;margin:0">
        <option value="">Все подразделения</option>
        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($d->id); ?>" <?php if(request('department_id')==$d->id): echo 'selected'; endif; ?>><?php echo e($d->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn" type="submit">Найти</button>
</form>

<table class="data">
    <thead>
    <tr><th>ФИО</th><th>Должность</th><th>Подразделение</th><th>Тел.</th><th>Доп.</th><th>Кабинет</th><th>Email</th></tr>
    </thead>
    <tbody>
    <?php $__empty_1 = true; $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><strong><?php echo e($e->fio); ?></strong> <?php if($e->role!=='employee'): ?> <span class="badge"><?php echo e($e->role); ?></span><?php endif; ?></td>
            <td><?php echo e($e->position); ?></td>
            <td><?php echo e($e->department?->short_name ?? '—'); ?></td>
            <td><?php echo e($e->phone ?? '—'); ?></td>
            <td><?php echo e($e->ext_phone ?? '—'); ?></td>
            <td><?php echo e($e->room ?? '—'); ?></td>
            <td><?php echo e($e->email ?? '—'); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="7" style="text-align:center;color:var(--muted)">Ничего не найдено</td></tr>
    <?php endif; ?>
    </tbody>
</table>

<div style="margin-top:16px"><?php echo e($employees->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspace/portal-php/resources/views/phonebook/index.blade.php ENDPATH**/ ?>