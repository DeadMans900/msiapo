<?php $__env->startSection('title', 'Кадры'); ?>
<?php $__env->startSection('content'); ?>
<div class="card">
    <h1 style="color:var(--primary)">Кадры</h1>
    <p style="margin-top:8px;color:var(--muted)">Раздел будет реализован на шаге «HR». Доступ: hr, chief, admin.</p>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspace/portal-php/resources/views/hr/placeholder.blade.php ENDPATH**/ ?>